package com.example.semana2pro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Actividad_recep extends AppCompatActivity {

    EditText nombre;
    EditText fecha;
    EditText telefono;
    EditText correo;
    EditText descripcion;
    Button editar;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent nuevo = new Intent (this, MainActivity.class);
            nuevo.putExtra ("nombre",nombre.getText ().toString ());
            nuevo.putExtra ("telefono",telefono.getText ().toString ());
            nuevo.putExtra ("correo",correo.getText ().toString ());
            nuevo.putExtra ("descripcion",descripcion.getText ().toString ());
            startActivity (nuevo);
        }
        return super.onKeyDown (keyCode, event);
        // se llama a la actividad que se elimino de memoria
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_actividad_recep);
        nombre = findViewById (R.id.nombre);
        fecha  = findViewById (R.id.fecha);
        telefono = findViewById (R.id.telefono);
        correo = findViewById (R.id.correo);
        descripcion = findViewById (R.id.descripcion);
        editar      = findViewById (R.id.Editar);

         Bundle parametros = getIntent().getExtras();
        nombre.setText ( parametros.getString("nombre"));
        fecha.setText (parametros.getString ("fecha"));
        telefono.setText (parametros.getString ("telefono"));
        correo.setText (parametros.getString ("correo"));
        descripcion.setText (parametros.getString ("descripcion"));



        editar.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent nuevo = new Intent (getBaseContext (), MainActivity.class);
                nuevo.putExtra ("nombre",nombre.getText ().toString ());
                nuevo.putExtra ("telefono",telefono.getText ().toString ());
                nuevo.putExtra ("correo",correo.getText ().toString ());
                nuevo.putExtra ("descripcion",descripcion.getText ().toString ());
                startActivity (nuevo);
                Bundle parametros = getIntent().getExtras();
                            }
        });

    }
}