package com.example.semana2pro;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText nombre;
    EditText telefono;
    EditText correo;
    EditText descripcion;
    DatePicker fecha;

    Button Enviar, Salir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        nombre = findViewById (R.id.nombre);
        fecha  = findViewById (R.id.fecha);
        telefono = findViewById (R.id.telefono);
        correo = findViewById (R.id.correo);
        descripcion = findViewById (R.id.descripcion);
        Enviar      = findViewById (R.id.enviar);
        Salir       = findViewById (R.id.salir);

       /* Bundle parametros = getIntent().getExtras();
        nombre.setText ( parametros.getString("nombre"));
        //fecha.setText (parametros.getString ("fecha"));
        telefono.setText (parametros.getString ("telefono"));
        correo.setText (parametros.getString ("correo"));
        descripcion.setText (parametros.getString ("descripcion"));*/


        // nombre.setOnClickListener(this);
        nombre.setOnFocusChangeListener (this::onFocusChange);
        telefono.setOnFocusChangeListener (this::onFocusChange);
        correo.setOnFocusChangeListener (this::onFocusChange);
        descripcion.setOnFocusChangeListener (this::onFocusChange);

        Salir.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent nuevo = new Intent (Intent.ACTION_MAIN);
                nuevo.addCategory (Intent.CATEGORY_HOME);
                nuevo.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity (nuevo);
            }
        });

        Enviar.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent nuevo = new Intent (MainActivity.this,Actividad_recep.class);
                nuevo.putExtra ("nombre",nombre.getText ().toString ());
                nuevo.putExtra ("fecha",String.valueOf (fecha.getDayOfMonth ()+"/"+fecha.getMonth ()+"/"+fecha.getYear ()));
                nuevo.putExtra ("telefono",telefono.getText ().toString ());
                nuevo.putExtra ("correo",correo.getText ().toString ());
                nuevo.putExtra ("descripcion",descripcion.getText ().toString ());
                startActivity(nuevo);
                finish(); // destruye la actividad anterior para no sobrecargar la memoria
            }
        });
    }
    public void onFocusChange(View v, boolean b) {
        if (b)
            switch (v.getId ()) {
                case R.id.nombre :
                    nombre.setText ("");
                    break;
                case R.id.telefono:
                    telefono.setText ("");
                    break;
                case R.id.correo:
                    correo.setText ("");
                    break;
                case R.id.descripcion:
                    descripcion.setText ("");
                    break;
                default:
                    break;
            }
        else
            switch (v.getId ()) {
                case R.id.nombre : if (nombre.getText ().length () == 0)
                                         nombre.setText (R.string.titulo2);
                    break;
                case R.id.telefono:  if (telefono.getText ().length () == 0)
                                        telefono.setText (R.string.titulo3);
                    break;
                case R.id.correo:    if (correo.getText ().length () == 0)
                                         correo.setText (R.string.titulo4);
                    break;
                case R.id.descripcion:  if (descripcion.getText ().length () == 0)
                                           descripcion.setText (R.string.titulo5);
                    break;
                default:
                    break;
            }


    }

}
